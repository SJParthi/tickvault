mod operator_movers_wire;
mod operator_stock_movers_wire;
mod operator_movers_universe;
use operator_movers_universe::*;
use std::io::Read;
fn main(){
    let mut input=String::new(); std::io::stdin().read_to_string(&mut input).unwrap();
    let filter: operator_stock_movers_wire::Filter=serde_json::from_str(&input).unwrap();
    let fixture:serde_json::Value=serde_json::from_str(&std::fs::read_to_string(std::path::Path::new(&std::env::var("TICKVAULT_EVIDENCE").unwrap()).join("questdb-input.json")).unwrap()).unwrap();
    let mut rows=Vec::new(); let mut names=Vec::new(); let mut members=Vec::new();
    for r in fixture["dataset"].as_array().unwrap(){
        let id=r[0].as_u64().unwrap();
        let stamp=chrono::DateTime::parse_from_rfc3339(r[6].as_str().unwrap()).unwrap().timestamp();
        rows.push(PriceRow{security_id:id,segment_code:1,ltp:r[2].as_f64().unwrap(),prev_close:r[3].as_f64(),volume:r[4].as_u64(),session_open:r[7].as_f64(),session_high:r[8].as_f64(),session_low:r[9].as_f64(),ts_ist_secs:stamp});
        names.push(ListedStock{security_id:id,segment_code:1,name:format!("DEMO{id:02}")}); members.push(StockIndices{security_id:id,segment_code:1,indices:vec![0]});
    }
    if std::env::args().any(|s|s=="legacy"){for r in &mut rows{r.session_open=None}}
    let at=rows[0].ts_ist_secs;let observed=at-UNIVERSE_IST_OFFSET_SECS;
    let args: Vec<_> = std::env::args().collect();
    let flag = |name: &str| args.iter().any(|arg|arg == name);
    let mtf = (!flag("--mtf-missing")).then(|| MtfTerms{
        observed_at_epoch_secs: if flag("--mtf-late") {observed+1} else {observed-3600},
        leverage_by_security_id: if flag("--mtf-zero"){[(2,0.),(4,0.),(6,0.),(8,0.)].into_iter().collect()}
        else {[(2,1.),(4,3.75),(6,0.)].into_iter().collect()}
    });
    let cutoff = filter.as_of.as_ref().map(|s|chrono::NaiveDateTime::parse_from_str(s,"%Y-%m-%dT%H:%M").unwrap().and_utc().timestamp()).unwrap_or(at);
    rows.retain(|r|r.ts_ist_secs <= cutoff);
    let universe=MoversUniverse{format_version:UNIVERSE_FORMAT_VERSION,trading_date_ist:"2026-11-25".into(),observed_at_epoch_secs:observed,read_at_ist_secs:cutoff,market_open:filter.as_of.is_none(),window_secs:900,prices:UniversePrices::Rows{rows},fno:Some(names[..2].to_vec()),membership:Some(UniverseMembership{mtf,names,indices:vec!["Nifty 50".into()],by_stock:members,partial:false})};
    assert!(universe.valid());let reply=select(&universe,&filter);assert!(reply.valid_at(observed,&filter));println!("{}",serde_json::json!({"ok":true,"movers":reply,"observed_at_epoch_secs":observed}));
}
