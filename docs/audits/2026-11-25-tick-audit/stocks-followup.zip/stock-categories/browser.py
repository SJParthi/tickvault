from pathlib import Path
import os
from playwright.sync_api import sync_playwright
import json, subprocess, time
root=Path(os.environ['TICKVAULT_REPO']); out=Path(os.environ.get('TICKVAULT_EVIDENCE',Path(__file__).resolve().parent));driver=os.environ['TICKVAULT_SELECTOR_DRIVER']
html=(root/'crates/aws-lambdas/src/operator_control_console.html').read_text();events=[];errors=[];requests=[];state={'legacy':False};
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox']);page=b.new_page(viewport={'width':1500,'height':950},device_scale_factor=1)
 page.on('pageerror', lambda e: errors.append(str(e)))
 def route(r):
  if r.request.method=='GET':return r.fulfill(body=html,content_type='text/html')
  body=r.request.post_data_json
  if body['action']=='stock-movers':
   f=body['filter'];requests.append(f);answered=dict(f);
   if state.get('old_box'):answered.pop('category',None)
   rep=subprocess.check_output([driver]+(['legacy'] if state['legacy'] else []),input=json.dumps(answered),text=True);return r.fulfill(body=rep,content_type='application/json')
  return r.fulfill(json={'ok':True},status=200)
 page.route('http://stocks.test/**',route); page.add_init_script("localStorage.setItem('tv_key',JSON.stringify({k:'local-fixture',e:Date.now()+86400000}))")
 page.goto('http://stocks.test/'); rows=page.locator('#movers-rows tr')
 def expect_row(first,qty,label,pct=None):
  page.wait_for_function("([stock,count])=>{const rows=document.querySelectorAll('#movers-rows tr');return rows.length===count&&(!count||rows[0].querySelector('.stock-name').textContent===stock)&&!document.querySelector('#movers-table').inert}",arg=[first,qty]);assert page.locator('#change-label').text_content()==label
  if qty and pct: assert rows.first.locator('td').nth(4).inner_text()==pct,(rows.first.inner_text(),pct)
  events.append({'request':requests[-1],'first':first,'count':qty,'column':label,'pct':pct,'meta':page.locator('#movers-meta').text_content(),'status':page.locator('#movers-status').text_content()})
 def go_category(v):page.locator(f'[data-category="{v}"]').click()
 def side(v):page.locator(f'[data-direction="{v}"]').click()
 expect_row('DEMO04',1,'Change','+10.00%')
 go_category('intraday');expect_row('DEMO08',2,'Change','+50.00%');assert requests[-1]['fno_only'] is False;page.screenshot(path=str(out/'intraday-gainers-local.png'))
 side('losers');expect_row('DEMO02',1,'Change','-1.00%')
 go_category('extreme_openings');expect_row('DEMO04',1,'From open','-12.00%');assert page.locator('[data-direction="losers"]').text_content()=='Open = High';page.screenshot(path=str(out/'extreme-open-high-local.png'))
 side('gainers');expect_row('DEMO02',1,'From open','+10.00%');assert page.locator('[data-direction="gainers"]').text_content()=='Open = Low';rows.first.locator('input').check();assert '-1.00' in page.locator('.watch-change').first.inner_text();page.screenshot(path=str(out/'extreme-open-low-local.png'))
 page.locator('#universe-picker').select_option('index:Nifty 50');expect_row('DEMO02',1,'From open','+10.00%');assert requests[-1]['index']=='Nifty 50'
 go_category('');expect_row('DEMO08',2,'Change','+50.00%');assert 'category' not in requests[-1]
 state['legacy']=True;go_category('extreme_openings');expect_row(None,0,'From open');assert 'No quotes with a usable session open, high and low.' in events[-1]['status'];assert '4 eligible stocks without a usable opening range' in events[-1]['status']
 state['legacy']=False;state['old_box']=True
 for mode in ('intraday','extreme_openings'):
  go_category(mode)
  page.wait_for_function("!document.querySelector('#movers-table').inert&&document.querySelector('#movers-status').textContent.includes('No verified snapshot')")
  assert rows.count()==0 and requests[-1]['category']==mode
 page.locator('#movers-date').fill('2026-11-25');page.locator('#movers-time').fill('10:00');go_category('intraday');go_category('extreme_openings');page.wait_for_function("!document.querySelector('#movers-table').inert&&document.querySelector('#movers-status').textContent.includes('No verified snapshot')");assert rows.count()==0 and requests[-1]['as_of']=='2026-11-25T10:00'
 assert not errors,errors;b.close()
(out/'browser.json').write_text(json.dumps({'source':'Chromium on current candidate HTML, local QuestDB result interpreted by the candidate Rust selector. Demo stocks are local fixtures.','events':events,'older_host_ignored_opening_category':{'intraday':'no rows displayed','extreme_openings':'no rows displayed','historical_extreme_openings':'no rows displayed'},'errors':errors,'watchlist_daily_change':'−1% retained for +10% recovery from the reported open = low'},indent=2)+'\n');print(len(events),'views checked',len(errors),'browser exceptions')
