#!/usr/bin/env bash
set -euo pipefail
: "${TICKVAULT_REPO:?set this to the source checkout}"
export TICKVAULT_EVIDENCE="$(cd "$(dirname "$0")" && pwd)"
trial="$(mktemp -d)"
trap 'rm -rf "$trial"' EXIT
mkdir -p "$trial/src"
cp "$TICKVAULT_EVIDENCE/Cargo.toml" "$TICKVAULT_EVIDENCE/Cargo.lock" "$trial/"
cp "$TICKVAULT_EVIDENCE/selector.rs" "$trial/src/main.rs"
cp "$TICKVAULT_REPO/crates/common/src/"operator_{movers_wire,stock_movers_wire,movers_universe}.rs "$trial/src/"
python3 "$TICKVAULT_EVIDENCE/quest.py"
CARGO_TARGET_DIR="$trial/target" cargo build --quiet --locked --manifest-path "$trial/Cargo.toml"
export TICKVAULT_SELECTOR_DRIVER="$trial/target/debug/tickvault-selector-measurement"
python3 "$TICKVAULT_EVIDENCE/browser.py"
