import json, subprocess, urllib.request, urllib.parse, time
from pathlib import Path
import os
out=Path(os.environ.get('TICKVAULT_EVIDENCE',Path(__file__).resolve().parent))
identity=subprocess.check_output(['docker','run','--rm','-d','-p','127.0.0.1::9000','questdb/questdb@sha256:22ad030544f45a396c743124c928ce33de11666c104f63f69ce4e66e07e7b968'],text=True).strip()
try:
 port=subprocess.check_output(['docker','port',identity,'9000/tcp'],text=True).strip()
 assert port.startswith('127.0.0.1:')
 def query(q):
  req='http://'+port+'/exec?'+urllib.parse.urlencode({'query':q}); return json.load(urllib.request.urlopen(req,timeout=5))
 for _ in range(80):
  try: version=query('select build()')['dataset'][0][0];break
  except Exception: time.sleep(.25)
 query('CREATE TABLE ticks (ts TIMESTAMP, security_id LONG, segment SYMBOL,feed SYMBOL,ltp DOUBLE,close DOUBLE,volume LONG,avg_price DOUBLE,open DOUBLE,high DOUBLE,low DOUBLE) TIMESTAMP(ts) PARTITION BY DAY BYPASS WAL')
 base="'NSE_EQ','dhan'"
 for entry in [('09:14:00',2,80,100,99,101,80),('10:00:00',2,99,100,90,110,90),('10:00:01',2,400,100,90,400,80),('10:00:00',4,110,100,125,125,100),('10:00:01',4,120,100,125,140,100),('10:00:00',6,101,None,100,110,99),('10:00:00',8,150,100,None,155,125)]:
  h,i,last,close,op,hi,lo=entry;query(f"INSERT INTO ticks VALUES ('2026-11-25T{h}Z',{i},{base},{last},{close if close is not None else 'null'},91,91,{op if op is not None else 'null'},{hi},{lo})")
 sql="SELECT security_id, segment, ltp, close, volume, avg_price, ts, open, high, low FROM ticks WHERE segment = 'NSE_EQ' AND feed = 'dhan' AND ts >= '2026-11-25T09:15:00.000000Z' AND ts <= '2026-11-25T10:00:00.000000Z' AND security_id IN (2,4,6,8) LATEST ON ts PARTITION BY security_id, segment LIMIT 1001"
 res=query(sql); data=sorted(res['dataset']); assert [(r[0],r[2],*r[7:10]) for r in data]==[(2,99,90,110,90),(4,110,125,125,100),(6,101,100,110,99),(8,150,None,155,125)]
 (out/'questdb-input.json').write_text(json.dumps({'source':'Local fixture on the production QuestDB schema shape; seeded session-open comparisons','engine':version,'query':sql,'columns':res['columns'],'dataset':data},indent=2)+'\n'); print(version,len(data))
finally: subprocess.run(['docker','rm','-f',identity],check=True,stdout=subprocess.DEVNULL)
