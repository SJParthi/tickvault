from pathlib import Path
from playwright.sync_api import sync_playwright
from datetime import datetime,timezone
import json
html=Path('/workspace/tickvault-nov25-followup/crates/aws-lambdas/src/operator_control_console.html').read_text()
out=Path('/workspace/shared/downloads/tickvault-followup-nov25')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1300,'height':740},locale='en-US')
 page.route('**/*',lambda r: r.fulfill(body=html, content_type='text/html') if r.request.resource_type=='document' else r.abort())
 page.goto('http://tickvault.test/')
 def read(sample):
  return page.evaluate("""async sample=>{call=async()=>sample;await loadLatency();return {network:document.getElementById('latnet').innerText,shields:[...document.querySelectorAll('#latnet .shield')].map(x=>[x.className,x.textContent]),sockets:document.getElementById('latws').textContent,cells:[...document.querySelectorAll('#latws tbody tr')].map(x=>[...x.cells].map(td=>td.textContent))};}""",sample)
 rows=[dict(connection='0',endpoint='main_feed',frames=450,instruments=3500,receive_buffer_bytes=1048576),dict(connection='1',endpoint='main_feed',frames=30,instruments=26,receive_buffer_bytes=None)]
 ok=read(dict(ws_latency=rows,questdb_ms='2.1',clock_skew_ms='-50.0',order_place_avg_ns=None)); assert ok['cells'][1][5]=='1,048,576' and ok['cells'][2][5]=='—'; assert [r[0] for r in ok['shields']]==['shield good','shield bad','shield idle'],ok
 empty=read(dict(ws_latency=[],questdb_ms='',clock_skew_ms='',order_place_avg_ns=None));assert all(r[0]=='shield idle' for r in empty['shields'])
 old=read(dict(ws_latency=[dict(connection='4',frames=25)],questdb_ms='0.0',clock_skew_ms='0.0',order_place_avg_ns=0)); assert old['cells'][1][5]=='—' and all(r[0]=='shield good' for r in old['shields'])
 missing=read(dict(ws_latency=[dict(connection='4',receive_buffer_bytes=16384),dict(connection='5',frames=0,never_received=True)],questdb_ms='',clock_skew_ms='',order_place_avg_ns=None))
 assert missing['cells'][1][3:6]==['—','—','16,384'] and missing['cells'][2][3:6]==['0','never','—']
 malformed=read(dict(ws_latency=[],questdb_ms='0oops',clock_skew_ms='12oops',order_place_avg_ns='10'));assert all(r[0]=='shield idle' for r in malformed['shields'])
 failure=read(None);assert not failure['shields'] and not failure['cells'] and 'unavailable' in failure['sockets']
 b.close()
out.joinpath('latency-panel-chromium.json').write_text(json.dumps({'observed_utc':datetime.now(timezone.utc).isoformat(),'kind':'local operator console with simulated authenticated replies','results':{'mixed':ok,'unknown':empty,'malformed':malformed,'missing_socket_counters':missing,'old_payload':old,'failed_after_success':failure}},indent=2)+'\n')
print('Chromium passed mixed socket buffers, old API response, missing measurements, and failure after success.')
