from pathlib import Path
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import urlopen
import hashlib, json, subprocess, re, time, threading, socket
from datetime import datetime,timezone
work=Path('/workspace/tickvault-nov25-followup')
dest=Path('/workspace/shared/downloads/tickvault-followup-nov25')
def command(*args, **kw): return subprocess.check_output(args,text=True,**kw).strip()
def probe_from(text):
    return next(x.strip()[3:-3] for x in text.splitlines() if ('curl' in x and 'QDB=' in x and 'SELECT%201' in x))
base=probe_from(command('git','-C',str(work),'show','d01b1fe90:crates/aws-lambdas/src/operator_control_commands.rs'))
candidate=probe_from((work/'crates/aws-lambdas/src/operator_control_commands.rs').read_text())
def run(src,port): return command('sh','-c',src.replace('127.0.0.1:9000','127.0.0.1:'+str(port)))
def fields(s):
    return dict(x.split('=',1) for x in s.splitlines() if '=' in x)
def verify(lines):
    d=fields(lines)
    try: j=json.loads(d.get('QDB_PROBE','')); t=float(d['QDB']); return 'error' not in j and j['dataset']==[[1]] and t>=0 and t<1e200
    except (KeyError,ValueError,TypeError): return False
def curl_case(label,port):
    old=run(base,port); new=run(candidate,port)
    return {'name':label,'old_reported_seconds':fields(old).get('QDB'),'candidate_seconds':fields(new).get('QDB'),'candidate_sql_verified':verify(new)}
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_GET(self):
        with self.server.lock: status,body=self.server.result
        self.send_response(status);self.end_headers();self.wfile.write(body)
cases=[]
server=ThreadingHTTPServer(('127.0.0.1',0), Handler);server.lock=threading.Lock();server.result=(500,b'')
t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
for name,status,body in [('http_503',503,b'{"error":"temporarily unavailable"}'),('sql_error_200',200,b'{"error":"query failed"}'),('wrong_row_200',200,b'{"dataset":[[0]]}'),('invalid_body_200',200,b'not json')]:
    with server.lock: server.result=(status,body)
    cases.append(curl_case(name,server.server_port))
port=server.server_port;server.shutdown();server.server_close();t.join()
cases.append(curl_case('connection_refused',port))
image='questdb/questdb@sha256:22ad030544f45a396c743124c928ce33de11666c104f63f69ce4e66e07e7b968'
cid=command('docker','run','--rm','-d','--label','tickvault.test=followup-query-latency','-p','127.0.0.1::9000',image)
try:
    port=command('docker','port',cid,'9000/tcp').split(':')[-1]
    for _ in range(90):
        try:
            with urlopen('http://127.0.0.1:'+port+'/exec?query=select%201',timeout=1) as r: assert json.load(r)['dataset']==[[1]]
            break
        except Exception: time.sleep(.35)
    cases.append(curl_case('real_questdb_9_3_5_correct_row',port))
finally: command('docker','rm','-f',cid)
assert all(c['old_reported_seconds'] is not None for c in cases)
assert [c['candidate_sql_verified'] for c in cases]==[False]*5+[True]
out={'observed_utc':datetime.now(timezone.utc).isoformat(),'old_commit':'d01b1fe90','candidate_command_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'isolated':True,'cases':cases}
(dest/'questdb-latency-probe.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
