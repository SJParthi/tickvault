const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(process.argv[2], 'utf8');
const read = (a,b) => {
  const start = html.indexOf(a);
  const end = html.indexOf(b, start);
  assert.ok(start >= 0 && end > start);
  return html.slice(start,end);
};
const elements = Object.create(null);
const el = id => elements[id] ??= { dataset: {}, innerHTML: '', textContent: '' };
let sample = null;
const ctx = { $:el, esc:String, call:async () => sample };
vm.createContext(ctx);
vm.runInContext(read('function shield(', 'function shieldIdle(') + html.match(/function shieldIdle\(t\)[^\n]+/)[0] + '\n' + read('async function loadAws()', 'function fmtNs('),ctx);
async function view(free,used,pct,size){
  sample = {disk_free_gb:free,disk_used_gb:used,disk_pct:pct,db_size_gb:size,alarms_firing:[]};
  await ctx.loadAws(); return el('storage').innerHTML;
}
(async()=>{
  assert.match(await view('21','10','90%','0'), /shield good[^]*Disk free[^]*21 GiB[^]*shield good[^]*Disk used[^]*90%[^]*Database size[^]*0 GiB/);
  assert.match(await view('20','10','91%',''), /shield bad[^]*Disk free[^]*20 GiB[^]*shield bad[^]*Disk used[^]*91%[^]*shield idle[^]*Database size/);
  assert.match(await view('0','100','100%','7'),/shield bad[^]*Disk free[^]*0 GiB/);
  assert.equal((await view('', '', '', '')).match(/shield idle/g).length,3);
  assert.equal((await view('12oops','45','190%','unknown')).match(/shield idle/g).length,3);
  await view('21','12','86%','3');
  sample = null; await ctx.loadAws(); assert.equal(el('storage').textContent,'Storage readings unavailable.');
  console.log('PASS: 6 production disk-panel rendering cases, including both alarm boundaries and a failed refresh after success.');
})().catch(e=>{console.error(e);process.exitCode=1});
