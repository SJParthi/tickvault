use std::{fs,path::{Path,PathBuf}};
use tickvault_storage::ws_frame_spill::{replay_all_with_report_guarded,confirm_replayed,WAL_REPLAY_RSS_STOP_PCT};
fn seq(sec:u64)->u64{((1_780_000_000+sec)*1_000_000_000)>>17<<17}
fn emit(dir:&Path,sec:u64)->PathBuf{
 let s=seq(sec);let payload=[0xABu8;32];let mut body=vec![1u8];
 body.extend(s.to_le_bytes());body.extend(7i64.to_le_bytes());body.push(0);
 body.extend((payload.len() as u32).to_le_bytes());body.extend(payload);
 let mut crc=u32::MAX;for n in &body{crc^=u32::from(*n);for _ in 0..8{crc=(crc>>1)^(if crc & 1!=0{0xEDB88320}else{0})}}
 let mut out=b"TVW4".to_vec();out.extend(body);out.extend((!crc).to_le_bytes());
 let p=dir.join(format!("ws-frames-{s:020}.wal"));fs::write(&p,out).unwrap();p
}
fn main(){
 let dir=PathBuf::from(std::env::args().nth(1).unwrap());let expect_hold=std::env::args().nth(2).unwrap()=="hold";
 let staging=dir.join("replaying");let archive=dir.join("archive");fs::create_dir_all(&staging).unwrap();
 let a=emit(&staging,10);let b=emit(&dir,15);let c=emit(&staging,20);let d=emit(&staging,30);
 let obstruction=dir.join(d.file_name().unwrap());fs::create_dir(&obstruction).unwrap();
 let pass=replay_all_with_report_guarded(&dir,1,||None,None,WAL_REPLAY_RSS_STOP_PCT);
 match pass {
   Ok(batch)=>{assert!(!expect_hold);assert_eq!(batch.frames.len(),1);confirm_replayed(&dir);assert!(archive.join(d.file_name().unwrap()).is_file());println!("baseline returned 1 frame and confirmed unread fourth segment into archive");}
   Err(e)=>{assert!(expect_hold&&e.to_string().contains("could not be restored"));assert!(a.is_file()&&b.is_file()&&d.is_file()&&!c.exists()&&dir.join(c.file_name().unwrap()).is_file());
     assert!(!archive.is_dir()||fs::read_dir(&archive).unwrap().count()==0);fs::remove_dir(&obstruction).unwrap();
     let retry=replay_all_with_report_guarded(&dir,usize::MAX,||None,None,WAL_REPLAY_RSS_STOP_PCT).unwrap();let ids:Vec<_>=retry.frames.iter().map(|f|f.frame_seq).collect();
     assert_eq!(ids,[seq(10),seq(15),seq(20),seq(30)]);confirm_replayed(&dir);
     assert_eq!(fs::read_dir(&archive).unwrap().count(),4);println!("candidate held failing pass, recovered 4 FIFO identities, confirmed 4 only after retry");}
 }
}
