from pathlib import Path
from html.parser import HTMLParser
from playwright.sync_api import sync_playwright
import base64,hashlib,json,mimetypes,os,re,subprocess,zipfile
root=Path(__file__).resolve().parents[1]
html=(root/'comparison.html').read_text()
def embed(m):
 k,name=m.groups()
 if name.startswith(('https://','#')):return m.group(0)
 path=root/name;assert path.is_file()
 mime=mimetypes.guess_type(name)[0] or 'application/octet-stream'
 data='data:'+mime+';base64,'+base64.b64encode(path.read_bytes()).decode()
 return k+'="'+data+'"'+(' download="'+path.name+'"' if k=='href' else '')
single=re.sub(r'(src|href|poster)="([^"]+)"',embed,html).replace('loading="lazy"','loading="eager"')
(root/'standalone-comparison.html').write_text(single)
class Check(HTMLParser):
 def handle_starttag(self,t,a):
  for k,v in a:
   if k in ('src','href','poster') and not v.startswith(('https://','#')):assert (root/v).is_file(),v
Check().feed(html)
data={}
with sync_playwright() as p:
 with p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking']) as b:
  ctx=b.new_context(offline=True);pg=ctx.new_page();network=[];errors=[]
  pg.on('request',lambda r:network.append(r.url) if r.url.startswith(('https://','http://')) else None)
  pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(single,wait_until='load',timeout=45000)
  for width,height in [(1366,920),(390,844)]:
   pg.set_viewport_size({'width':width,'height':height})
   pg.wait_for_function('Number.isFinite(document.querySelector("video").duration)&&[...document.images].every(x=>x.complete&&x.naturalWidth>0)')
   d=pg.evaluate('''()=>({width:innerWidth,body:document.documentElement.scrollWidth,rows:document.querySelectorAll('tbody tr').length,images:document.images.length,chapters:document.querySelectorAll('#chap option').length,duration:document.querySelector('video').duration})''')
   assert d['rows']==d['images']==4 and d['chapters']==5 and d['body']==d['width'] and d['duration']>45
   data[str(width)]=d
  pg.locator('#chap').select_option(index=3);pg.wait_for_function('Math.abs(+document.querySelector("#chap").value-document.querySelector("video").currentTime)<1')
  pg.evaluate('''()=>{let v=document.querySelector("video");v.currentTime=1;v.muted=true;return v.play()}''')
  pg.wait_for_function('document.querySelector("video").currentTime>1.3',timeout=10000)
  assert not network and not errors
  data.update({'external_requests':0,'page_errors':0,'offline_video_playback':True,'chapter_jump':True})
(root/'browser-qa.json').write_text(json.dumps(data,indent=2)+'\n')
key=os.environ.get('TICKVAULT_OPERATOR_KEY','').encode()
if key:
 assert len(key)>5
 assert all(key not in path.read_bytes() for path in root.rglob('*') if path.is_file() and path.suffix!='.zip')
chapter_titles=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','chapter_tags=title','-of','json',str(root/'stocks-walkthrough.mp4')]))['chapters'];assert len(chapter_titles)==5
archive=root/'tickvault-stocks-briefing.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for path in sorted(root.rglob('*')):
  if path.is_file() and path!=archive:z.write(path,path.relative_to(root))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(hashlib.sha256(archive.read_bytes()).hexdigest(),data)
