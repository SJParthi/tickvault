from pathlib import Path
from functools import lru_cache
from html import escape
import hashlib,json,math,subprocess,textwrap,wave,zipfile
from PIL import Image,ImageDraw,ImageFont
from tempfile import TemporaryDirectory
root=Path(__file__).resolve().parents[1];ev=root/'evidence';work=TemporaryDirectory();temp=Path(work.name)
get=lambda name:json.loads((ev/name).read_text())
live=get('live-observations.json');release=get('release.json');timing=get('interaction-timing.json')
rows=live['filters'];keys=['fno-losers','fno-gainers','nifty50-gainers','nifty50-losers']
fl,fg,ng,nl=(rows[k] for k in keys);returned=sum(x['row_count'] for x in rows.values());turnover=sum(x['rows_with_turnover'] for x in rows.values())
assert returned==65 and turnover==0 and all(x['market_open'] and x['rows_correct_membership_sign_and_order'] for x in rows.values())
assert all(x['rendered_rows']==x['row_count'] for x in rows.values()) and len(set(live['source_revision_labels']))==3
build=live['source_revision_labels'][0].split()[-1]
assert all(x.split()[-1]==build for x in live['source_revision_labels'])
head=release['head'][:9]
names={'fno-losers':'F&O losers','fno-gainers':'F&O gainers','nifty50-gainers':'Nifty 50 gainers','nifty50-losers':'Nifty 50 losers'}
fps=12;W,H=1280,720
bg='#101b1c';dark='#0a1212';card='#1b2a2a';foreground='#edf4ee';mut='#b0c4bc';mint='#7fdbb3';rose='#f79b9b';line='#354744';gold='#f5c67f'
@lru_cache(None)
def font(size,bold=False):return ImageFont.truetype('/usr/share/fonts/truetype/open-sans/OpenSans-'+('Bold' if bold else 'Regular')+'.ttf',size)
def txt(d,xy,s,size=24,c=foreground,bold=False,anchor='lt'):d.text(xy,str(s),font=font(size,bold),fill=c,anchor=anchor)
def rr(d,coords,color,r=12):d.rounded_rectangle(coords,r,fill=color)
def lines(d,x,y,s,maxwidth,size=22,c=mut):
 words=s.split();out=['']
 for w in words:
  v=(out[-1]+' '+w).strip()
  if out[-1] and d.textlength(v,font=font(size))>maxwidth:out.append(w)
  else:out[-1]=v
 for i,v in enumerate(out):txt(d,(x,y+i*(size+8)),v,size,c)
def frame(title,tag,chapter):
 im=Image.new('RGB',(W,H),bg);d=ImageDraw.Draw(im)
 txt(d,(46,23),'TICKVAULT',20,mint,True);txt(d,(181,24),'Stocks',19,mut)
 txt(d,(1234,25),'25 NOV 2026   /   12:28 IST',17,mut,True,'rt');d.line((45,61,1235,61),fill=line,width=2)
 txt(d,(45,80),tag.upper(),16,mint,True);txt(d,(43,112),title,41,foreground,True)
 for i in range(5):
  x=45+i*240;rr(d,(x,698,x+227,702),mint if i<=chapter else line,2)
 return im,d
screens={k:Image.open(ev/(k+'.png')).convert('RGB') for k in keys}
def crop_display(im,img,region,box):
 x,y,w,h=box;clip=img.crop(region).resize((w,h),Image.Resampling.LANCZOS);im.paste(clip,(x,y))
def card_text(d,x,y,w,h,lab,big,body,tint=mint):
 rr(d,(x,y,x+w,y+h),card);txt(d,(x+24,y+22),lab,17,tint,True);txt(d,(x+23,y+68),big,45,foreground,True);lines(d,x+24,y+145,body,w-48,21)
labels=[names[k] for k in keys]
fast=min(x['browser_action_until_response_body_ms'] for x in rows.values());slow=max(x['browser_action_until_response_body_ms'] for x in rows.values())
chap=[
 ('Find the stocks you want', 'Production screen · NSE Price Movers',
 'Open Markets, then Stocks and Price Movers. The switch chooses rising or falling stocks. The menu on the right chooses a group. F and O means stocks eligible for futures and options. Nifty Fifty is an index.'),
 ('Watch the selections change','Browser recording · original timing',
 'Here is the real screen. First, F and O losers. Switch to gainers, change the group to Nifty Fifty, and finally switch back to losers. The stock rows change each time.'),
 ('How many stocks matched?', 'Live results · first page',
 'A page holds twenty stocks. In the F and O group, one hundred and sixty were rising and fifty-seven were falling. For Nifty Fifty, forty-five were rising. All five falling members fit on one page.'),
 ('What did the page know?', 'Live results · data availability',
 'A dash means the value was unavailable. None of the sixty-five row appearances in these four views supplied traded value. The page did have prices for two hundred and eighteen of two hundred and thirty-six F and O stocks, and all fifty index members.'),
 ('Which version was running?', 'Live browser and GitHub · separate checks',
 'The live portal, server binary, and main revision agreed. The audit-repair changes were in an open draft pull request at the time of capture. The four filter changes took between about a third of a second and two point four seconds to return their responses. Those are four observations, not a p ninety-nine benchmark.')
]
ff=['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-y']
subprocess.run(ff+['-i',str(ev/'stocks-interaction.mp4'),'-vsync','0',str(temp/'ui-%04d.png')],check=True)
rawpaths=sorted(temp.glob('ui-*.png'))
@lru_cache(4)
def ui(i):return Image.open(rawpaths[i]).convert('RGB')
def draw(i,t,total):
 title,tag,_=chap[i];img,d=frame(title,tag,i)
 if i in [0,1]:
  if i==0:
   cut=screens['fno-losers'];region=(30,70,1550,560);dest=(43,181,1194,385)
   crop_display(img,cut,region,dest)
   base_x,base_y=dest[:2];sx=dest[2]/(region[2]-region[0]);sy=dest[3]/(region[3]-region[1])
   for a,b,after in [(1145,1320,0.15),(1419,1540,0.40)]:
    if t/total>=after:
     box=(int(base_x+(a-region[0])*sx),int(base_y+(140-region[1])*sy),int(base_x+(b-region[0])*sx),int(base_y+(178-region[1])*sy));d.rounded_rectangle(box,5,outline=gold,width=3)
   txt(d,(47,594),'Direction',23,mint,True);txt(d,(181,594),'Gainers or Losers',22)
   txt(d,(46,638),'Group',23,mint,True);txt(d,(181,638),'F&O Stocks, Nifty 50 or another available index',22)
  else:
   clock=min(t,timing['duration_s']);pos=min(len(rawpaths)-1,int(clock*fps))
   region=(386,74,1546,494);dest=(44,175,1192,432)
   crop_display(img,ui(pos),region,dest)
   started=[x for x in timing['actions'] if x['start']<=clock]
   caption=names[started[-1]['selection']] if started else 'F&O stocks'
   txt(d,(46,633),caption,25,foreground,True)
   txt(d,(1230,638),f"{clock:.1f} s · "+('Final frame' if t>=timing['duration_s'] else 'Original capture'),18,mut,False,'rt')
 elif i==2:
  xs=[69,386,664,970];ys=[263,377,478,577]
  rr(d,(45,191,1235,616),card)
  txt(d,(xs[0],218),'GROUP',16,mut,True);txt(d,(xs[1],218),'GAINERS',16,mint,True);txt(d,(xs[2],218),'LOSERS',16,rose,True);txt(d,(xs[3],218),'PRICED / ELIGIBLE',16,mut,True)
  for j,(label,up,down,priced,eligible) in enumerate([('F&O Stocks',fg,fl,fl['stocks_priced'],fl['universe_total']),('Nifty 50',ng,nl,ng['stocks_priced'],ng['universe_total'])]):
   y=286+j*145;d.line((69,y-23,1208,y-23),fill=line,width=1);txt(d,(xs[0],y+3),label,31,foreground,True)
   for x,v,c in [(xs[1],up,mint),(xs[2],down,rose)]:
    txt(d,(x,y),str(v['matching_total']),42,c,True);txt(d,(x,y+62),f"{v['row_count']} on page",20,mut)
   txt(d,(xs[3],y+4),f'{priced} / {eligible}',30,foreground,True)
  txt(d,(47,642),'Every returned row matched the selected group, direction and percentage order.',22,mut)
 elif i==3:
  crop_display(img,screens['nifty50-losers'],(1368-160,180,1535,498),(45,191,480,423))
  card_text(d,547,191,688,423,'TRADED VALUE AVAILABLE',f'{turnover} / {returned}',"The Value (Cr.) column had a dash in every returned row. Volume counts shares. Traded value is the money exchanged.",gold)
  txt(d,(47,642),'Index membership coverage was marked partial in all four responses.',22,mut)
 else:
  card_text(d,45,191,574,365,'DEPLOYED AT 12:28 IST',build,'The live portal, binary and main labels showed the same revision.',mint)
  card_text(d,646,191,589,365,'PR #2300 AT CAPTURE',head,'GitHub listed the repair revision as an open draft.',gold)
  txt(d,(48,593),f'{fast:,.0f}–{slow:,.0f} ms',30,foreground,True)
  txt(d,(48,646),'Four browser actions timed to the response body. Each selection was timed once.',21,mut)
 return img
segments=[];samples=[];offset=0;cues=[]
for i,(title,_,speech) in enumerate(chap):
 src=temp/f'voice{i}.txt';src.write_text(speech)
 wav=temp/f'v{i}.wav';subprocess.run(ff+['-f','lavfi','-i',f'flite=voice=slt:textfile={src}','-ar','24000','-ac','1',str(wav)],check=True)
 with wave.open(str(wav),'rb') as w:pcm=w.readframes(w.getnframes())
 n=math.ceil((len(pcm)/48000+.45)*fps);segments.append(n);samples.append(pcm+bytes(n*4000-len(pcm)));cues.append((offset,offset+n,speech));offset+=n
with wave.open(str(temp/'narration.wav'),'wb') as w:w.setparams((1,2,24000,0,'NONE','NONE'));w.writeframes(b''.join(samples))
def stamp(n):
 v=round(n/fps*1000);return f'{v//3600000:02}:{v//60000%60:02}:{v//1000%60:02}.{v%1000:03}'
vtt=root/'captions.vtt';vtt.write_text('WEBVTT\n\n'+'\n\n'.join(stamp(a)+' --> '+stamp(b)+'\n'+s for a,b,s in cues)+'\n')
(root/'transcript.txt').write_text('\n\n'.join(title+'\n'+s for title,_,s in chap)+'\n')
chapter_meta=temp/'chapters.ffmeta';chapter_meta.write_text(';FFMETADATA1\n'+'\n'.join(f'[CHAPTER]\nTIMEBASE=1/1000\nSTART={round(a/fps*1000)}\nEND={round(b/fps*1000)}\ntitle={chap[i][0]}' for i,(a,b,_) in enumerate(cues))+'\n')
video=root/'stocks-walkthrough.mp4'
proc=subprocess.Popen(ff+['-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r',str(fps),'-i','-','-i',str(temp/'narration.wav'),'-i',str(vtt),'-i',str(chapter_meta),'-map','0:v','-map','1:a','-map','2:0','-map_chapters','3','-c:v','libx264','-crf','19','-preset','veryfast','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','96k','-c:s','mov_text','-metadata:s:s:0','language=eng','-movflags','+faststart',str(video)],stdin=subprocess.PIPE)
for i,n in enumerate(segments):
 last=None
 for f in range(n):
  key=min(f,len(rawpaths)-1) if i==1 else int(f/n*10) if i==0 else i
  if key!=last:render=draw(i,f/fps,n/fps).tobytes();last=key
  proc.stdin.write(render)
proc.stdin.close();assert proc.wait()==0
draw(2,3,4).save(root/'stocks-comparison.png')
G=[];delays=[]
for i,n in enumerate(segments):
 for t in ([0,1,4.7,6.4,8.3] if i==1 else [0,n/fps*.6]):
  G.append(draw(i,t,n/fps).resize((864,486),Image.Resampling.LANCZOS).quantize(colors=128));delays.append(1400 if i==1 else 1900)
G[0].save(root/'stocks-walkthrough.gif',save_all=True,append_images=G[1:],duration=delays,loop=0,disposal=2)
def row_table():
 return ''.join('<tr><th scope="row">'+escape(names[k])+'</th><td>'+str(r['row_count'])+' / '+str(r['matching_total'])+'</td><td>'+str(r['stocks_priced'])+' / '+str(r['universe_total'])+'</td><td>'+str(r['rows_with_turnover'])+'</td><td>'+f"{r['browser_action_until_response_body_ms']:,.2f} ms"+'</td></tr>' for k,r in rows.items())
output='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Tickvault Stocks · 25 November 2026</title><style>*{box-sizing:border-box}body{background:#101b1c;color:#edf4ee;font:17px/1.55 system-ui,sans-serif;margin:0}main{width:min(94%,1050px);margin:2rem auto 5rem}h1{font-size:clamp(2rem,6vw,4rem);line-height:1.12}h2{margin:2rem 0 .45rem}a{color:#84e4bb}video,img{width:100%;height:auto;border-radius:10px}table{border-collapse:collapse;width:100%;background:#1b2a2a}td,th{padding:.7rem;text-align:left;border-bottom:1px solid #4b5a56}thead{color:#84e4bb}section{overflow:auto}figure{margin:1em 0}details{margin:1.2rem 0}select{padding:.4rem}</style><main><p>Tickvault · 25 November 2026</p><h1>Stocks Price Movers</h1><p>In the live 12:28 IST capture, every displayed stock matched its selected group and direction. Gain and loss percentages were ordered correctly for all four selections.</p><video controls preload="metadata" poster="stocks-comparison.png"><source src="stocks-walkthrough.mp4" type="video/mp4"><track src="captions.vtt" kind="captions" srclang="en" label="English"></video><p><label for="chap">Jump to a chapter </label><select id="chap">'''+''.join(f'<option value="{a/fps}">{escape(chap[i][0])}</option>' for i,(a,b,_) in enumerate(cues))+'''</select></p><script>document.querySelector('#chap').onchange=function(){document.querySelector('video').currentTime=+this.value}</script><p><a href="evidence/stocks-interaction.mp4">Original browser recording</a> · <a href="stocks-walkthrough.gif">Animated GIF</a> · <a href="transcript.txt">Narration transcript</a></p><section><h2>What the page returned</h2><table><thead><tr><th>Selection</th><th>Shown / matched</th><th>Priced / eligible</th><th>Rows with turnover</th><th>Action to response</th></tr></thead><tbody>'''+row_table()+'''</tbody></table></section><p>The browser timed one action per selection through receipt of its response body. These four observations cannot establish p99. The group and direction results overlap across selections. Index membership was marked partial.</p><p><a href="evidence/live-observations.json">Browser and API evidence</a> · <a href="evidence/interaction-timing.json">Recording times</a></p><h2>Find an index</h2><p>Choose the universe picker to the right of NSE. The live menu included F&amp;O Stocks, Nifty 50, Nifty Bank and Fin Nifty. The India VIX entry was disabled in this capture.</p><details><summary>All observed menu choices</summary><ul>'''+''.join('<li>'+escape(o['label'])+('' if o['enabled'] else ' (disabled)')+'</li>' for o in live['available_options'])+'''</ul></details><h2>Current release at capture</h2><p>The live page displayed revision <strong>'''+build+'''</strong>. GitHub reported PR #2300 as an open draft at <strong>'''+head+'''</strong> during this check.</p><p><a href="evidence/release.json">Timestamped release evidence</a> · <a href="'''+escape(release['source'])+'''">PR #2300</a></p><h2>Production screenshots</h2>'''+''.join('<figure><img loading="lazy" src="evidence/'+k+'.png" alt="'+escape(names[k])+' selected on the live Stocks page."><figcaption>'+escape(names[k])+' · '+r['selected_ist']+' IST</figcaption></figure>' for k,r in rows.items())+'''<p>Synthesized US English narration using Flite SLT. The screen sequence uses the original browser timing and holds the final frame while the voice finishes.</p></main></html>'''
(root/'comparison.html').write_text(output)
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,codec_name,nb_frames,duration:chapter_tags=title','-of','json',str(video)]))
vv,aa,ss=[next(y for y in probe['streams'] if y['codec_type']==kind) for kind in ('video','audio','subtitle')]
assert len(probe['chapters'])==5 and int(vv['nb_frames'])==offset and aa['codec_name']=='aac' and ss['codec_name']=='mov_text'
subprocess.run(['ffmpeg','-v','error','-i',str(video),'-f','null','-'],check=True)
subprocess.run(['ffmpeg','-v','error','-i',str(ev/'stocks-interaction.mp4'),'-f','null','-'],check=True)
with Image.open(root/'stocks-walkthrough.gif') as g:
 durations=[]
 for i in range(g.n_frames):g.seek(i);g.load();durations.append(g.info['duration'])
 assert sum(durations)==sum(delays)
receipt={'production_revision':build,'pull_request_head_at_check':release['head'],'video_duration_s':float(vv['duration']),'video_frames':offset,'chapters':len(chap),'captions':len(cues),'audio':'AAC English Flite SLT narration','frame_capture':'Authenticated Markets panel only','gif_duration_s':sum(delays)/1000,'narrated_mp4_sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'tests':'Decoded full video and original capture, checked caption and chapter streams, loaded all GIF frames.'}
(root/'media-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt)
