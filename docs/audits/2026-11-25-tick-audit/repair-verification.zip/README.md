# Tickvault handoff after the November 25 market-session checks

Open `viewer/comparison.html` for the comparison table and narrated video. Open `continue-in-claude.md` to resume the branch in an isolated checkout. Fetch the published branch directly from GitHub. The companion Claude Code handoff ZIP includes two Git bundles under `git/` that can also be imported in numerical order into a clone containing main history through `9ccd99e7`. The second bundle was restored in a fresh bare repository and recovered its full advertised head and evidence archive.

## Release state

Production ran `9ccd99e7`. The Stocks rebuild was already merged in #2187. Draft #2300 remained open at `ca905eec6`. Its five dependency upgrades are the changes from the still-open #2289. The follow-up branch descended from that reviewed head and contains the daily database receipt repair (`18537fe00`) and the same-day WebSocket evidence repair (`b9d90717a`). `b6cb4ef0d` also includes the November 25 verification archive. The prior cloud-only `a9b0e89c` could not be resolved in GitHub, in the restored checkout, or in the earlier branch archive. Of the 59 historical names originally left for content review, seven were traced to equivalent landed changes and three to a documented retirement. The 49 others remain preserved for individual review.

## Measurements and remaining work

| Check | Evidence |
|---|---|
| Live Stocks | All displayed 20 F&O losers and 20 Nifty 50 gainers passed membership, sign and sort checks. 218/236 F&O had prices. Index coverage was partial. Traded value and ticker prices were unavailable. |
| Live operational state | The order-management boot record confirms dry-run mode. A live gauge and boot record confirm both depth sockets disabled. The database recorded five sockets connecting before market open and zero persisted disconnects/reconnects in the 09:15–10:48 IST cash-session window. A missing audit record is possible. |
| Production speed | API Gateway reported 2,533.879 ms p99 across 14 requests during one five-minute interval. This is a stage measurement. The three benchmarked in-process four-quote paths on the original PR measured 1.206, 2.446 and 2.438 µs p99. |
| Receipt safety | The isolated storage repair recovered exactly one receipt in ten scenarios and reported zero confirmed copies when disk and database both refused it. The enhanced scoreboard required five producer and two writer counters to accept a zero. All 31 targeted scoreboard scenarios passed. |
| Cost of durable audit | On a disk-backed local QuestDB, 1,000 healthy receipt writes per path measured 20.192 ms p99 original and 83.477 ms p99 journal-first. All 2,064 rows, warmups included, persisted through database restart. |
| Selector correctness | The exact selector matched an independent reference on 5,827,536 complete replies. These included every assignment and input order of a three-stock finite model and a 41-stock pagination fixture. Two release runs agreed. |
| Incremental research | The standalone Rust experiment matched all four reference pages across 11,880 comparisons. At 1,000 inputs, applying one delta and publishing four pages measured 547.722 µs p99, compared with 6,772.628 µs to do the full selection and encoding. One indexed update costs O(log n). The experiment is separate from deployed code. |
| Languages | Eight first-party Rust packages. The local app binary links AWS-LC and ring native cryptographic code. The repository also contains shell, SQL, Terraform and the operator frontend. |
| Disk and calendar | Latest root-disk reading was 47.97% used and spill had 77.95 GiB free. The previous growth alarm and repeated lag alarm were retired. All 16 configured 2026 weekday holidays matched the annual NSE capital-market circular plus its election-day amendment. The configured year ends December 31. An official 2027 annual circular was not located in this review. |

The cash-session check accessed the production database and operator portal read-only. Failure tests ran on local fixtures. Daily accepted/stored counts cannot certify individual tick identities. Full Rust line coverage, constant-time processing for variable-size results, sub-microsecond end-to-end response and continuous market connectivity remain unmet guarantees.

[Single integration PR](https://github.com/SJParthi/tickvault/pull/2300) · [Follow-up branch](https://github.com/SJParthi/tickvault/tree/fix/audit-recovery-and-feed-report-20261125) · [Original CI](https://github.com/SJParthi/tickvault/actions/runs/45539365285) · [Frame benchmarks](https://github.com/SJParthi/tickvault/actions/runs/45546320350) · [Follow-up CI](https://github.com/SJParthi/tickvault/actions/runs/45552287623) · [2026 NSE holidays](https://nsearchives.nseindia.com/content/circulars/CMTR71775.pdf) · [Election-day amendment](https://nsearchives.nseindia.com/content/circulars/CMTR72260.pdf)

## Hosted verification of the two repairs

GitHub finished the exact b6cb4ef0d workflow at 11:14 IST on November 25. Sixteen jobs passed and four event-specific jobs were skipped. The eight crate test jobs recorded 18,659 passes and 39 skips. Hosted whole-workspace production line coverage was 117,800 of 139,698 (84.32% as reported), leaving 21,898 uncovered. All 11 local publication gates had already passed. The optional local typos executable was unavailable. [Follow-up LLVM job](https://github.com/SJParthi/tickvault/actions/runs/45552287623/job/138997669285)

For new executable production Rust lines relative to the original draft, hosted LLVM recorded 132/148 (89.19%). Against main, the combined changes recorded 193/209 (92.34%). The same 16 changed lines lacked a hit. Nine belonged to receipt delivery, three to scheduling, two to feed counter parsing, one to startup, and one to the journal. Some corresponding behaviors were exercised separately in the independent database experiments. The per-line files keep that evidence distinct from hosted coverage.
