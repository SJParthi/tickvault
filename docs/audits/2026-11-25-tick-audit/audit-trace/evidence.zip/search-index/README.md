# Correlation-ID index experiment

The Rust probe queried 100,000 generated paper-order rows in a fresh QuestDB 9.3.5 database restricted to the loopback interface. The schema came from Tickvault commit `34aa4860c`. Both the existing ID and its event were checked against the expected seven-field SQL result. The absent ID had to return an empty result on every call. All 6,400 timed reads and 480 warm-ups passed these checks.

| Pooled HTTP p99 on this runner | Existing ID, plain | Existing ID, indexed | Missing ID, plain | Missing ID, indexed |
|---|---:|---:|---:|---:|
| Index added and dropped on the same table, two blocks per arm | 14.956 ms | 22.895 ms | 15.331 ms | 21.091 ms |
| Cloned tables, both arms shuffled within each round | 4.336 ms | 4.191 ms | 4.101 ms | 3.407 ms |

Each table entry represents 800 warm-state measurements. The first experiment used plain → indexed → indexed → plain on the same table and exact SQL text, with 400 observations per case per block after 40 warm-ups. The second shuffled all four queries in 800 rounds after 40 warm-up rounds and used separate identically populated tables. On the existing table, EXPLAIN showed a forward row scan with a two-worker JIT filter. With the bitmap index, EXPLAIN showed an index forward scan on `correlation_id`, including a deferred lookup for the nonexistent symbol.

The indexed plan reduced p99 in the interleaved experiment. Its pooled p99 rose in the repeated same-table experiment. The timings varied across blocks. This single cardinality and single partition cannot establish worst-case O(1) behavior or a production latency limit. None of the 6,400 measured client round trips completed within one microsecond.

## Cost

Adding the index to 100,000 existing rows took 213.086 ms from submission through confirmation of the indexed schema and visible row count. The DDL HTTP response alone took 2.170 ms. Removing it took 76.059 ms through confirmation. Each alteration was observed once.

Two cloned tables accepted ten identical batches of 10,000 generated rows. The order of the two writes alternated by batch. Median elapsed time until the full batch could be counted was 77.534 ms without the index and 151.607 ms with it. Median insert acknowledgement times were 17.935 and 17.187 ms. Visibility was polled at 10 ms intervals.

The indexed table's applied data partition used 211.508 MiB more allocated space on this filesystem. The fixture used 100,000 distinct symbols and the default bitmap block capacity of 256. WAL files and table-wide symbol files are outside this measurement. File preallocation affects the result.

## Inspect the evidence

- `summary.json` contains independently recalculated pooled percentiles, timings per block, limits and metadata.
- `paired.json` and `interleaved.json` contain exact SQL, query plans, expected result sets and individual client and server observations.
- `bulk.json` and `space.json` contain the 20 individual batch timings and per-partition file measurements.
- `source.zip` contains the three measured Rust clients, a frozen schema reference and a replay guide. The database and volume used for the experiment belong only to this test.
