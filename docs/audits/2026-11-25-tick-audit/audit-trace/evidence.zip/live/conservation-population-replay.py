"""Reproduce duplicate accepted-operation versus persisted unique-key counts on isolated QuestDB. Does not touch AWS."""
import argparse,json,re,subprocess,tempfile,time,urllib.parse,urllib.request
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument("repo",type=Path)
parser.add_argument("--rev",default="9ccd99e7331cfbed723c3def69d8aac6295632fb")
parser.add_argument("--out",type=Path,default=Path(__file__).with_name("conservation-population-replay.json"))
parser.add_argument("--rustc",default="rustc")
args=parser.parse_args()
def run(*cmd):
 return subprocess.check_output(cmd,text=True).strip()
def source(path):
 return run("git","-C",str(args.repo),"show",args.rev+":"+path)
root=Path(__file__).resolve().parent
img="questdb/questdb@sha256:22ad030544f45a396c743124c928ce33de11666c104f63f69ce4e66e07e7b968"
with tempfile.TemporaryDirectory() as tmp:
 folder=Path(tmp);ledger=source("crates/storage/src/tick_conservation_ledger.rs");(folder/'ledger.rs').write_text(ledger)
 audit=source("crates/app/src/tick_conservation.rs")
 def block(name):
  start=audit.index(name);p=audit.index('{',start)+1;level=1
  while level:
   if audit[p]=='{':level+=1
   if audit[p]=='}':level-=1
   p+=1
  return audit[start:p]
 day=1795564800*1_000_000_000
 (folder/"main.rs").write_text('#![allow(dead_code)]\nmod ledger;\n#[derive(Debug)]\n'+block('pub enum ConservationVerdict')+'\n'+block('pub struct ConservationInputs')+'\n'+block('pub const fn classify')+f"""
fn main() {{
 let mut args=std::env::args().skip(1);
 let offered=args.next().unwrap().parse::<u64>().unwrap();
 let db=args.next().unwrap().parse::<u64>().unwrap();
 let d={day}_i64;
 let l=ledger::TickConservationLedger::new();
 for _ in 0..offered {{ l.note_row_appended(d); }}
 let accepted=l.accepted_rows_on(ledger::TickConservationLedger::ist_day_of(d));
 let (v,reason)=classify(ConservationInputs{{accepted_rows:accepted,not_landed_rows:l.rows_not_landed(),db_rows:Some(db),full_coverage:true}});
 println!("{{accepted}} {{}} {{:?}} {{reason}}",l.rows_not_landed(),v);
}}
""")
 run(args.rustc,"--edition=2024","-O",str(folder/'main.rs'),"-o",str(folder/'ledger'))
 tickkey=re.search(r'pub const DEDUP_KEY_TICKS: &str = "([^"]+)";',source("crates/storage/src/tick_persistence.rs")).group(1)
 quotekey=re.search(r'pub const DEDUP_KEY_TICK_QUOTES: &str = "([^"]+)";',source("crates/storage/src/tick_quotes_persistence.rs")).group(1)
 assert tickkey==quotekey
 template=re.search('"(select count\\(\\) from \\{table\\}[^"]+)"',block('pub fn tick_count_sql')).group(1)
 def daily_table_count(table):
  return template.replace('{table}',table).replace('{}','2026-11-25',1).replace('{}','dhan',1)
 cid=run("docker","run","--rm","-d","-p","127.0.0.1::9000",img)
 try:
  bind=run("docker","port",cid,"9000/tcp");assert bind.startswith("127.0.0.1:")
  def sql(s):
   with urllib.request.urlopen('http://'+bind+'/exec?'+urllib.parse.urlencode({'query':s}),timeout=5) as r:
    d=json.load(r);assert 'error' not in d,d;return d.get('dataset',[])
  for _ in range(150):
   try:version=sql('select build()')[0][0];break
   except OSError:time.sleep(.2)
  else:raise RuntimeError('QuestDB unavailable')
  for table in ('ticks','tick_quotes'):
   sql(f'CREATE TABLE {table} (ts timestamp,security_id long,segment symbol,capture_seq long,feed symbol,ltp double) timestamp(ts) partition by hour WAL DEDUP UPSERT KEYS ({tickkey})')
  def settle(table):
   for _ in range(150):
    view=sql(f"SELECT suspended, writerTxn, sequencerTxn FROM wal_tables() WHERE name = '{table}'")
    if view and view[0][0] is False and view[0][1]==view[0][2]:return
    time.sleep(.05)
   raise RuntimeError(f'WAL did not settle: {table}')
  offered=0;results=[]
  def submit(table,seq,price=100):
   global offered
   sql(f"INSERT INTO {table} VALUES ('2026-11-25T15:25:05.000000Z',2,'NSE_EQ',{seq},'dhan',{price})");offered+=1;settle(table)
  def observe(name):
   counts={k:sql(daily_table_count(k))[0][0] for k in ('ticks','tick_quotes')}
   text=run(str(folder/'ledger'),str(offered),str(sum(counts.values())))
   results.append({'case':name,'offered':offered,'database':counts,'checked_with_original_ledger_and_classify':text,'stored_trade_rows':sql("select capture_seq,ltp from ticks order by capture_seq")})
  submit('ticks',4096);submit('tick_quotes',8192);observe('two distinct submissions')
  submit('ticks',4096);observe('same-key identical trade replay submitted again')
  submit('tick_quotes',8192);observe('same-key identical quote replay submitted again')
  submit('ticks',4097);observe('distinct next packet from the same frame')
  assert [r['checked_with_original_ledger_and_classify'] for r in results]==['2 0 Match exact','3 0 Mismatch unexplained_shortfall','4 0 Mismatch unexplained_shortfall','5 0 Mismatch unexplained_shortfall']
  assert [sum(r['database'].values()) for r in results]==[2,2,2,3]
  args.out.write_text(json.dumps({'scope':'Isolated replay only. Mirrors the operation-to-row mismatch using the checked-out source ledger and classifier; no live input or production-causality inference. Row submission here uses SQL against a reduced schema containing all source DEDUP fields.','revision':args.rev,'questdb':version,'source_ddl_upsert_keys':tickkey,'source_day_count_queries':[daily_table_count(t) for t in ('ticks','tick_quotes')],'states':results},indent=2)+'\n')
  print(version,len(results),'checked states')
 finally:
  subprocess.run(['docker','rm','-f',cid],stdout=subprocess.DEVNULL,check=True)
