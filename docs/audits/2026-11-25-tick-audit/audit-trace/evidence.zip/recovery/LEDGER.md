# Audit persistence and recovery evidence

Source: `34aa4860c8e5cf3227b0de79aba373ac782de2ea`. This review read immutable Git objects and retained receipts; it ran no new faults or tests and changed no repository, GitHub or production state. Ongoing worktree edits are excluded.

The current daily receipt path is **QuestDB plus a local ILP journal**. Two earlier controlled runs each verified **2,064 synthetic rows across both comparison arms**, all 11 fields, before and after an ordinary database restart. Their catalog module's production code is byte-identical to this head, but they are historical runs. A separate real EACCES-after-ack receipt verifies identical replay bytes and one resulting logical row. Neither result proves literal disk-full or power-loss recovery.

| ID | Area | Evidence / limit |
|---|---|---|
| R01 | Actual backing and row scope | QuestDB table and flat-file journal exist; no SQLite dependency in the scoped manifest scan. No live DB inspection. |
| R02 | 2,064 synthetic rows after restart | Two historical runs: 2,064 rows each = 1,032 baseline + 1,032 catalog, including warmups; all fields checked across restart. No request IDs. |
| R03 | Missing/refused schema and catalog lag | Current strict HTTP regressions cover catalog backoff/exhaustion and DDL refusal/recovery; historical real-DB cases cover wrong schema/non-WAL tables. |
| R04 | Lost acknowledgement / duplicate keyed replay | Real post-ack EACCES retained journal; same bytes replayed once; DB stayed at one logical row after restart. Current mock regression covers the unlink branch. |
| R05 | Earlier process-death / outage replay | Earlier candidate process-death/outage fixtures recovered one logical row; original baseline failures remain preserved and are not relabeled green. |
| R06 | Journal cap / local refusal | Logical cap/path refusal and replay accounting are tested. Both journal and DB unavailable means no confirmed durable receipt. |
| R07 | Literal disk full | No actual daily-journal ENOSPC recovery receipt. The generic ulimit test has a weak nonzero-exit assertion and does not establish process survival. |
| R08 | fsync failure / crash before rename / power loss | File sync/rename/directory sync are implemented. Directory-sync failure weakens durability; stale partial files are quarantined. Power loss remains unproven. |
| R09 | Frame WAL acknowledged in RAM | Frame WAL enqueue is not a completed durable write. SIGKILL tests verify a surviving prefix; queued frames remain a documented loss window. |
| R10 | Logging, metrics and debug visibility | Warning/error logs and counters exist. Debug detail is filtered at the default info level; production export/retention/search was not verified. |
| R11 | Request IDs and identity-level reconciliation | Daily table has aggregate counts and a composite replay key, not request/trace IDs. Separate order correlation IDs may be empty. |
| R12 | Fresh exact-head CI and real DB lane | Exact-tree CI: storage 3,744 passed and real DB restart 1 passed. The real-DB lane covers ticks/depth/candles, not the daily-audit table. |

`LEDGER.json` contains exact test IDs, immutable source links/line numbers and receipt filenames. `SOURCE-PARITY.json` records the historical/current byte comparison; `RECEIPT-PROVENANCE.json` identifies every copied primary receipt and hash. `SOURCE-ANCHORS.json` indexes bounded source excerpts.

The hosted run passed 18,718 tests with 39 skipped across eight crates. Production line coverage was 118,587/140,617 (84.33% truncated), not 100% or exhaustive branch coverage. Successful individual test lines are suppressed in the CI profile; the listed nonignored IDs come from source and are included in the passing target scope.

The remaining material assurance gaps are literal journal write/sync failure, host power loss, terminal failure of both persistence tiers, and a universal searchable identity trail. An acknowledged HTTP write, a log line, a counted append and a durable/queryable unique database row are distinct observations.

[Exact hosted CI](https://github.com/SJParthi/tickvault/actions/runs/45597489248) · [coverage artifact](https://github.com/SJParthi/tickvault/actions/runs/45597489248/artifacts/15015063131)
