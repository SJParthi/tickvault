# Audit receipt in the Stocks service dashboard

Two synthetic Dhan audit checks were each submitted twice to an isolated QuestDB through Tickvault’s Rust storage writer. Four acknowledged writes produced two daily rows. A SQL lookup restricted to November 25, Dhan, mismatch, and unexplained shortfall returned one row.

| Step | Measured result | Evidence |
| --- | --- | --- |
| Read the stored row | 2,064 accepted writes, 2,060 stored rows, difference 4, spill counter 0 | [SQL result](database-readback.json) |
| Open the protected JSON endpoint | Anonymous request returned 401. Authenticated reads returned 200, first on a cache miss, then on a hit with the same capture time. | [HTTP response](protected-api-online.json) |
| View the red row in Chromium | fewer stored rows than accepted writes. The card showed the persisted check time down to microseconds and the three database count reads. | [Screenshot](dashboard-online.png) and [captured text](browser-observation.json) |
| Stop the database while the dashboard is open | The browser refreshed automatically and removed both dated counts. The card showed “could not read” and “the database did not answer”. | [Screenshot](dashboard-db-down.png) |
| Read the protected JSON with the database stopped | A fresh cache miss at 1795607144010 followed by a cache hit returned the same sole grey tile. Earlier green and red rows were absent. | [HTTP response](protected-api-db-down.json) |

The tested handler came from commit d586381cf48370270230b7fa4b851a5039c00280 with SHA-256 92c40e8e05dff40cf0d014ea198f85f5738fcbdd5c8c8f484a1a14c626da411a. The native Rust API router and QuestDB ran on loopback with a temporary bearer token. Chromium 154.0.8037.57 opened the service route `/dashboard`. This experiment used synthetic rows and exercised the service’s existing five-second refresh and cache timers. The daily audit compares aggregate counts. Per-tick identity and production availability require separate evidence.

[Build and scope details](provenance.json)
