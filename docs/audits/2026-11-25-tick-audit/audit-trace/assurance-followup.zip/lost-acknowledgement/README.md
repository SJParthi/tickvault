# Duplicate delivery after an acknowledgement was lost

QuestDB accepted one synthetic Tickvault daily-audit row and returned HTTP 204. A local proxy dropped that response. The native writer reported `QueuedForReplay` and left one journal file on disk. A separate Rust process replayed the same bytes, received another 204 and removed the file. Running the drain again found zero files.

| Read | Stored result |
| --- | --- |
| Before replay | One row with 37 accepted writes, 35 stored rows, a difference of 2 and 3 count reads |
| After replay and WAL application | One row with all 11 fields identical. Writer and sequencer transactions both reached 3. |
| After restarting the disposable QuestDB process | The same one row and all 11 fields survived. Writer and sequencer transactions still matched. |

The input and both HTTP write bodies had SHA-256 `ef585a79c53f73cb89dd27ce4f7c68f2c7d0b014cef7dbb43555018b64930449`. The fixture used Tickvault commit `9d808e6331c0b125a1ddfa6fdc4c744edf957e6e`, the real storage writer and replay drain, and QuestDB 9.3.5 on loopback. This run covers one daily-audit receipt. It establishes no production tick-loss rate. A separate existing native regression also passed for a successful database acknowledgement followed by failed journal removal.

[HTTP, database, and restart evidence](receipt.json) · [Native regression result](native-test.txt)
