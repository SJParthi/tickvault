# Historical Groww branches and the August retirement

Three of the 52 branch names still open after the patch comparison exclusively concern the retired Groww order system. This leaves **49 historical names requiring content review** out of the original 59. The earlier seven have historical landing evidence. These three have a documented retirement covering their contents. All three original refs remain available.

| Historical branch | What its full branch diff contains | Evidence and disposition at main `9ccd99e7` |
|---|---|---|
| `claude/groww-fanout-error-code-stubs` · `f719774c5` | Nine files covering the Groww portfolio, smart-order OCO and margin error contracts, operating guides, triage rows, config and tests. | Merged #1587 introduced the same 14 named Rust error variants, all absent in its parent. One of the nine complete source files matched exactly at #1587. #1796 later retired the entire order surface, removed the order-gate test and modified the common config and error codes. The 14 variants are absent at the inspected main. The three runbooks remain under `docs/error-runbooks/`. **Retired product scope.** [Old diff](https://github.com/SJParthi/tickvault/compare/5f852eab19bdd61009fb1b1ee0340ee4ba644ec4...f719774c577e2b5825b00a6ebd111e7f3454abb6) · [Merged contracts](https://github.com/SJParthi/tickvault/pull/1587) |
| `claude/groww-order-shared-scaffold` · `3d7298ba5` | Two documentation files, 59 added lines. They specify ownership of Groww order gates, market-hours-only order and portfolio reads, post-close handling and order/position push on the then-existing connection. | The later scope decision names both the §39 order gate and the order/position/trade push channel as removed. The historical documents cannot authorize reinstating these paths. A byte-identical landing of the extra July prose was unverified. **Retired product scope.** [Old diff](https://github.com/SJParthi/tickvault/compare/d3bb4b752fefca5be853f7070e805409fe637768...3d7298ba57849f81bbca0bbfeed101b43fbcafb4) · [Specific retirement row](https://github.com/SJParthi/tickvault/blob/9ccd99e7331cfbed723c3def69d8aac6295632fb/docs/claude-rules-full/project/websocket-connection-scope-lock.md#L1783) |
| `claude/groww-smart-orders` · `7c57ad008` | Only `crates/trading/src/oms/groww/mod.rs` and the Groww GTT/OCO `smart_orders.rs`. | Merged #1602 introduced a separately integrated implementation. Its file differed from the historical branch. The main history for this module shows its introduction at #1602 and deletion at #1796. The latter also removed the module root and the other Groww order modules, and none exists at the inspected main. **Retired product scope.** [Old diff](https://github.com/SJParthi/tickvault/compare/d3bb4b752fefca5be853f7070e805409fe637768...7c57ad008169b114d003c75380aa8dbe5e9f90a4) · [Integrated feature](https://github.com/SJParthi/tickvault/pull/1602) · [Removal](https://github.com/SJParthi/tickvault/pull/1796) |

The July 15 change in #1581 retired the Groww live market-data WebSocket. The August 21 rule explicitly extended retirement to the REST grants and §39 order side. The August 22 implementation in #1796 then removed the trading modules. The same rule preserves the historical Groww rows in `instrument_lifecycle`, `instrument_lifecycle_audit` and `index_constituency`. These are source and Git-history findings. They say nothing about a current AWS database or deployed server. [July change](https://github.com/SJParthi/tickvault/pull/1581) · [Current scope text](https://github.com/SJParthi/tickvault/blob/9ccd99e7331cfbed723c3def69d8aac6295632fb/docs/claude-rules-full/project/groww-second-feed-scope-2026-06-19.md#L3-L25) · [Actual removal commit](https://github.com/SJParthi/tickvault/commit/6395012fab02cf40079428eeaf36338dd78e0ddc)

One control illustrates why absence from current code alone is insufficient. `claude/gdf-1s-client` concerns a separate vendor, Global Data Feeds. The inspected main lists Dhan and TrueData in `Feed::ALL`, but still contains a GDF trial-first scope rule and an archived plan marked DRAFT. That evidence leaves the GDF branch unresolved. [Feed registry](https://github.com/SJParthi/tickvault/blob/9ccd99e7331cfbed723c3def69d8aac6295632fb/crates/common/src/feed.rs#L30-L44) · [GDF scope](https://github.com/SJParthi/tickvault/blob/9ccd99e7331cfbed723c3def69d8aac6295632fb/.claude/rules/project/gdf-third-feed-scope-2026-07-13.md) · [Draft plan](https://github.com/SJParthi/tickvault/blob/9ccd99e7331cfbed723c3def69d8aac6295632fb/.claude/plans/archive/2026-07-13-gdf-feed.md#L3)

The findings were checked with read-only Git object queries in the recovered clone.

```sh
git diff --stat 5f852eab f719774c5
git diff d3bb4b752 3d7298ba5
git diff --stat d3bb4b752 7c57ad008
git show 6395012fa --format=full --name-status
git log --first-parent --oneline 9ccd99e7 -- crates/trading/src/oms/groww/smart_orders.rs
git ls-tree -r 9ccd99e7 -- crates/trading/src/oms/groww crates/common/tests/groww_order_lattice_guard.rs
git grep -nE 'Groww(Port|Oco|Marg)[0-9]{2}' 503cc8784 -- crates/common/src/error_code.rs
git grep -nE 'Groww(Port|Oco|Marg)[0-9]{2}' 9ccd99e7 -- crates/common/src/error_code.rs
```
