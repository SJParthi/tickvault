# Historical branch reconciliation for November 25

Of 59 branch names previously marked for content review, six have a recoverable main revision that matches every path changed on that branch, including file modes, object IDs and deletions. A seventh has the same normalized change on main, with a Terraform alignment-space difference. This file-level comparison left 52 historical names. The separate Groww order review traced three more to a documented retirement, leaving **49 historical names** for individual review. [Groww order scope and evidence](groww-orders-semantic-review.md) It records what reached main in the past. Later commits can and did change these paths.

| Historical branch | Evidence on main | Result |
|---|---|---|
| claude/29-tf-phase-2-14-dlq-reason-static | [fba0fc9cc](https://github.com/SJParthi/tickvault/commit/fba0fc9cc5314077977550e194f2685cdf5caba2) · fix(storage): Phase 2.14 — DLQ reason tightened to &'static str (security MEDIUM) (#480) | All 2 changed paths matched at once |
| claude/daily-universe-scope-aware-subscription | [c1b3dced2](https://github.com/SJParthi/tickvault/commit/c1b3dced26139295e5f09363fa4c204af20c61e1) · feat: GO-LIVE — flip prod default to DailyUniverse 250-SID scope (PR-3) (#854) | All 5 changed paths matched at once |
| claude/fix-clippy-useless-conversion | [a87dc734f](https://github.com/SJParthi/tickvault/commit/a87dc734f8872c7d9c5a0f334f98e672a39a63d1) · fix(boot): gate docker-compose CRITICAL on QuestDB health + drop useless conversion (#1288) | All 1 changed paths matched at once |
| claude/fix-questdb-console | [e1f533007](https://github.com/SJParthi/tickvault/commit/e1f53300736f5c4a1c7c2b2c3a12bb9d7e815efc) · fix(ci): satisfy deploy SSM-quoting lint — no raw apostrophes in commands block (#1369) | All 3 changed paths matched at once |
| claude/parity-sp5-unified-audit | [37fda7882](https://github.com/SJParthi/tickvault/commit/37fda7882c8685ef8bb7e64d8d6fe628917f258a) · docs: lock Groww to live-feed-only; halt backtest parity (operator 2026-06-26) (#1206) | All 1 changed paths matched at once |
| claude/phase-0-items-15-28-29-bar-correction | [939c7ace5](https://github.com/SJParthi/tickvault/commit/939c7ace51b9fbec9f7e613e208b3180310ccb60) · feat(phase-0): Items 15+28+29 FOUNDATION (rebased) — bar_correction_audit + comparator + Telegram + ErrorCode (#699) | All 10 changed paths matched at once |
| claude/aws-resume-jul9 | [de12ffb7e](https://github.com/SJParthi/tickvault/commit/de12ffb7e58a235b152f0d6b34cb8e757019e770) · revert: resume normal AWS schedule (operator GO 2026-07-06 — moved up from Jul 9) (#1427) | Four of five resulting files identical. The fifth differs only in spacing before the Terraform assignment of ENABLED. |

The Rust programs compared the full net branch patch, walked 2,012 first-parent main commits and reconstructed the production tree. Each six-branch match was verified by a separate git ls-tree call against that historical main commit. A partial file count, a lack of patch match, or one matching file alone cannot settle the remaining branches. All historical refs were preserved.

To reproduce, use the full-history branch bundle and original disposition table. Run the following in that Git repository with the Rust scripts and disposition table available.

```sh
git -c diff.renames=false log --first-parent -m --no-renames -p --format=medium 9ccd99e7 | git patch-id --stable > main-patch-ids.tsv
rustc -O compare.rs -o compare
./compare branch-dispositions.tsv main-patch-ids.tsv 9ccd99e7331cfbed723c3def69d8aac6295632fb results.tsv
rustc -O tree_history.rs -o tree_history
./tree_history results.tsv 9ccd99e7331cfbed723c3def69d8aac6295632fb tree-history.tsv
```
