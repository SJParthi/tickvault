use std::{
    collections::HashMap,
    env, fs,
    io::Write,
    process::{Command, Stdio},
};

fn git(args: &[&str]) -> String {
    let output = Command::new("git").args(args).output().expect("start Git");
    assert!(
        output.status.success(),
        "{args:?}: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    String::from_utf8(output.stdout).expect("UTF-8 Git metadata")
}

fn net_patch(base: &str, head: &str) -> String {
    let mut diff = Command::new("git")
        .args(["diff", "--no-renames", base, head])
        .stdout(Stdio::piped())
        .spawn()
        .unwrap();
    let id = Command::new("git")
        .args(["patch-id", "--stable"])
        .stdin(diff.stdout.take().unwrap())
        .output()
        .unwrap();
    assert!(id.status.success() && diff.wait().unwrap().success());
    String::from_utf8(id.stdout)
        .unwrap()
        .split_whitespace()
        .next()
        .unwrap_or("")
        .into()
}

fn tracked_at(revision: &str) -> HashMap<String, String> {
    git(&["ls-tree", "-r", "-z", revision])
        .split('\0')
        .filter_map(|line| {
            line.split_once('\t')
                .map(|(id, path)| (path.into(), id.into()))
        })
        .collect()
}

fn main() {
    let args: Vec<String> = env::args().collect();
    assert_eq!(
        args.len(),
        5,
        "compare inventory.tsv main-patch-ids.tsv main-sha results.tsv"
    );
    let main = &args[3];
    let main_tree = tracked_at(main);
    let patches = fs::read_to_string(&args[2]).unwrap();
    let mut by_id = HashMap::new();
    for pair in patches.lines().filter_map(|line| line.split_once(' ')) {
        by_id.entry(pair.0).or_insert_with(Vec::new).push(pair.1);
    }
    let mut out = fs::File::create(&args[4]).unwrap();
    writeln!(out, "branch\thead\tmerge_base\tnet_patch_id\tmain_first_parent_patch_matches\tchanged_paths\texact_current_paths\tcurrent_paths_differ\tunique_nonmerge_commits\tunique_merge_commits\tfirst_parent_patch_equivalent_nonmerge_commits").unwrap();
    for line in fs::read_to_string(&args[1]).unwrap().lines().skip(1) {
        let cols: Vec<&str> = line.split('\t').collect();
        if cols[2] != "Requires content review" {
            continue;
        }
        let (branch, head) = (cols[0], cols[1]);
        let base = git(&["merge-base", main, head]);
        let base = base.trim();
        let path_list = git(&["diff", "--no-renames", "--name-only", "-z", base, head]);
        let paths: Vec<_> = path_list.split_terminator('\0').collect();
        let old_tree = tracked_at(head);
        let exact = paths
            .iter()
            .filter(|&&p| main_tree.get(p) == old_tree.get(p))
            .count();
        let id = net_patch(base, head);
        let matches = by_id
            .get(id.as_str())
            .map(|hits| hits.join(","))
            .unwrap_or_default();
        let range = format!("{main}..{head}");
        let nonmerges = git(&["rev-list", "--no-merges", &range]);
        let merge_count = git(&["rev-list", "--count", "--merges", &range]);
        let mut equivalent = 0;
        for rev in nonmerges.lines() {
            let parent = format!("{rev}^");
            let commit_patch_id = net_patch(&parent, rev);
            if by_id.contains_key(commit_patch_id.as_str()) {
                equivalent += 1
            }
        }
        writeln!(
            out,
            "{branch}\t{head}\t{base}\t{id}\t{matches}\t{}\t{exact}\t{}\t{}\t{}\t{equivalent}",
            paths.len(),
            paths.len() - exact,
            nonmerges.lines().count(),
            merge_count.trim()
        )
        .unwrap();
    }
}
