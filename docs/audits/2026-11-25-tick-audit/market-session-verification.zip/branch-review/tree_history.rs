use std::{
    collections::{BTreeMap, HashMap, HashSet},
    env, fs,
    io::Write,
    process::Command,
};

fn git(args: &[&str]) -> String {
    let result = Command::new("git").args(args).output().unwrap();
    assert!(
        result.status.success(),
        "{args:?}: {}",
        String::from_utf8_lossy(&result.stderr)
    );
    String::from_utf8(result.stdout).unwrap()
}

type Files = HashMap<String, (String, String)>;
fn tree(sha: &str) -> Files {
    git(&["ls-tree", "-r", "-z", sha])
        .split_terminator('\0')
        .map(|record| {
            let (meta, path) = record.split_once('\t').unwrap();
            let m = meta.split_whitespace().collect::<Vec<_>>();
            (path.into(), (m[0].into(), m[2].into()))
        })
        .collect()
}

struct Review {
    branch: String,
    head: String,
    eligible: HashSet<String>,
    paths: Vec<(String, Option<(String, String)>)>,
    best: usize,
    at: String,
    first_full: Option<String>,
}
fn main() {
    let args: Vec<_> = env::args().collect();
    assert_eq!(
        args.len(),
        4,
        "tree_history initial_comparison.tsv main-sha output.tsv"
    );
    let main = &args[2];
    let commits = git(&["rev-list", "--reverse", "--first-parent", main]);
    let mut reviews = vec![];
    for record in fs::read_to_string(&args[1]).unwrap().lines().skip(1) {
        let c: Vec<_> = record.split('\t').collect();
        let after = tree(c[1]);
        let paths = git(&["diff", "--no-renames", "--name-only", "-z", c[2], c[1]])
            .split_terminator('\0')
            .map(|p| (p.into(), after.get(p).cloned()))
            .collect();
        let range = format!("{}..{main}", c[2]);
        let eligible = git(&["rev-list", "--first-parent", "--ancestry-path", &range])
            .lines()
            .map(String::from)
            .collect();
        reviews.push(Review {
            branch: c[0].into(),
            head: c[1].into(),
            eligible,
            paths,
            best: 0,
            at: String::new(),
            first_full: None,
        });
    }
    let logs = git(&[
        "-c",
        "core.quotePath=false",
        "log",
        "--format=@%H",
        "--first-parent",
        "--diff-merges=first-parent",
        "--root",
        "--no-renames",
        "--raw",
        "--no-abbrev",
        main,
    ]);
    let mut deltas: BTreeMap<&str, Vec<(&str, &str, &str)>> = BTreeMap::new();
    let mut id = "";
    for l in logs.lines() {
        if let Some(h) = l.strip_prefix('@') {
            id = h;
        }
        if l.starts_with(':') {
            let (meta, path) = l.split_once('\t').unwrap();
            let m: Vec<_> = meta.split_whitespace().collect();
            deltas.entry(id).or_default().push((path, m[1], m[3]));
        }
    }
    let mut current = Files::new();
    for h in commits.lines() {
        if let Some(changes) = deltas.get(h) {
            for &(p, mode, oid) in changes {
                if mode == "000000" {
                    current.remove(p);
                } else {
                    current.insert(p.into(), (mode.into(), oid.into()));
                }
            }
        }
        for r in reviews.iter_mut().filter(|r| r.eligible.contains(h)) {
            let matches = r
                .paths
                .iter()
                .filter(|(p, desired)| current.get(p) == desired.as_ref())
                .count();
            if matches > r.best {
                r.best = matches;
                r.at = h.into();
            }
            if matches == r.paths.len() && r.first_full.is_none() {
                r.first_full = Some(h.into());
            }
        }
    }
    assert_eq!(
        current,
        tree(main),
        "replayed final tree must equal actual main"
    );
    let mut out = fs::File::create(&args[3]).unwrap();
    writeln!(out,"branch\thead\tnet_changed_paths\tbest_simultaneous_exact_file_matches\tfirst_main_with_best\tfirst_main_matching_entire_set").unwrap();
    for r in reviews {
        if let Some(h) = r.first_full.as_ref() {
            let verify = tree(h);
            assert!(r.paths.iter().all(|(p, b)| verify.get(p) == b.as_ref()));
        }
        writeln!(
            out,
            "{}\t{}\t{}\t{}\t{}\t{}",
            r.branch,
            r.head,
            r.paths.len(),
            r.best,
            r.at,
            r.first_full.unwrap_or_default()
        )
        .unwrap();
    }
}
